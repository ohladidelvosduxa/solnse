import React, { useState } from 'react';

function App() {
  const [currentScreen, setCurrentScreen] = useState('main'); // main, window, notebook

  // Стили для контейнера в зависимости от экрана
  const containerStyle = {
    width: '100vw',
    height: '100vh',
    margin: 0,
    padding: 0,
    backgroundColor: currentScreen === 'main' ? '#32CD32' : 
                     currentScreen === 'window' ? '#FFD700' : '#000000',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    transition: 'background-color 0.5s ease',
    position: 'relative',
  };

  // Стили для надписей
  const textStyle = {
    color: currentScreen === 'main' ? 'black' : 'white',
    fontSize: '48px',
    fontWeight: 'bold',
    margin: '10px',
    cursor: 'pointer',
    transition: 'transform 0.3s ease, color 0.5s ease',
  };

  // Стили для солнца (логотипа)
  const sunStyle = {
    position: 'absolute',
    top: '20%',
    width: '100px',
    height: '100px',
    backgroundColor: 'yellow',
    borderRadius: '50%',
    boxShadow: '0 0 30px #FFFF00',
    zIndex: 1,
    animation: 'glow 2s infinite alternate',
  };

  // Солнечные лучи
  const sunRaysStyle = {
    position: 'absolute',
    top: '20%',
    width: '120px',
    height: '120px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  };

  // Стиль для лучей
  const rayStyle = {
    position: 'absolute',
    width: '60px',
    height: '10px',
    backgroundColor: 'yellow',
    borderRadius: '5px',
    opacity: 0.7,
  };

  // Создаем 8 лучей
  const rays = [];
  for (let i = 0; i < 8; i++) {
    const angle = (i * 45) * Math.PI / 180;
    rays.push(
      <div 
        key={i} 
        style={{
          ...rayStyle,
          transform: `rotate(${i * 45}deg) translateY(-40px)`,
          animation: `rayPulse ${2 + i * 0.2}s infinite alternate`,
        }}
      />
    );
  }

  // Кнопка возврата на главный экран (на других экранах)
  const returnButtonStyle = {
    position: 'absolute',
    bottom: '20px',
    padding: '10px 20px',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    fontSize: '18px',
  };

  return (
    <div style={containerStyle}>
      <style>
        {`
          @keyframes glow {
            from { box-shadow: 0 0 30px #FFFF00; }
            to { box-shadow: 0 0 50px #FFFF00, 0 0 60px #FFFF00; }
          }
          @keyframes rayPulse {
            from { opacity: 0.5; }
            to { opacity: 0.9; }
          }
        `}
      </style>
      
      {/* Логотип солнца (только на главном экране) */}
      {currentScreen === 'main' && (
        <>
          <div style={sunStyle}></div>
          <div style={sunRaysStyle}>{rays}</div>
        </>
      )}
      
      {/* Надписи */}
      <div style={{ display: 'flex', gap: '30px' }}>
        <h1 
          style={{
            ...textStyle,
            color: currentScreen === 'main' ? 'black' : 
                  currentScreen === 'window' ? 'white' : 'white',
          }}
          onClick={() => setCurrentScreen('window')}
          onMouseOver={(e) => e.target.style.transform = 'scale(1.1)'}
          onMouseOut={(e) => e.target.style.transform = 'scale(1)'}
        >
          окно
        </h1>
        
        <h1 
          style={{
            ...textStyle,
            color: currentScreen === 'main' ? 'black' : 
                  currentScreen === 'window' ? 'white' : 'white',
          }}
          onClick={() => setCurrentScreen('notebook')}
          onMouseOver={(e) => e.target.style.transform = 'scale(1.1)'}
          onMouseOut={(e) => e.target.style.transform = 'scale(1)'}
        >
          тетрадь
        </h1>
      </div>

      {/* Кнопка возврата (на других экранах) */}
      {currentScreen !== 'main' && (
        <button 
          style={returnButtonStyle}
          onClick={() => setCurrentScreen('main')}
        >
          Вернуться на главную
        </button>
      )}
    </div>
  );
}

export default App;